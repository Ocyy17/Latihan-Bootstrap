<?php include 'db.php'; ?> <!-- include langsung db.php karena sudah di root -->
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Portfolio Saya</title>
<link href="bootstrap-5.3.8-dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
/* Navbar */
.navbar-brand img { height: 80px; width: 80px; border-radius: 50%; }

/* Section Backgrounds */
#hero { height:100vh; background: linear-gradient(rgba(0,0,0,0.4),rgba(0,0,0,0.7)), url('FotoBG1.jpg') no-repeat center/cover; display:flex; align-items:center; justify-content:center; text-align:center; color:white; }
#services { background:url('FotoBG2jpg.jpg') no-repeat center/cover; color:white; }
#stats { background:url('khususchart.jpg') no-repeat center/cover; color:white; }
#contact { background:url('FotoBG.jpg') no-repeat center/cover; color:black; }


/* Fade-in Animations */
.from-left,.from-right,.from-top,.from-bottom{opacity:0;transition:all 1s ease;}
.from-left{transform:translateX(-50px);} 
.from-right{transform:translateX(50px);} 
.from-top{transform:translateY(-50px);} 
.from-bottom{transform:translateY(50px);}
.show{opacity:1; transform:translateX(0) translateY(0);}

section{padding:80px 0;}
.card{background-color: rgba(0,0,0,0.5);}
.card-title,.card-text{color:white;}
</style>
</head>
<body data-bs-spy="scroll" data-bs-target=".navbar" data-bs-offset="70" tabindex="0">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top shadow-sm">
<div class="container">
  <a class="navbar-brand" href="#hero"><img src="FotoMacan.jpg" alt="Logo Portfolio"></a>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"><span class="navbar-toggler-icon"></span></button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ms-auto">
      <li class="nav-item"><a class="nav-link" href="#hero">Home</a></li>
      <li class="nav-item"><a class="nav-link" href="#services">Services</a></li>
      <li class="nav-item"><a class="nav-link" href="#stats">Statistik</a></li>
      <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
    </ul>
  </div>
</div>
</nav>

<!-- Hero Section -->
<section id="hero">
  <div class="container text-center">
    <h1 class="fs-1 fw-bold from-left">Hello, My Name is Theodore Roxy Indra Putra</h1>
    <p class="fs-5 from-right mt-3">Student's of Mechatronics ATMI | Gamer | Tukang Jajan</p>
    <a href="#services" class="btn btn-primary btn-lg mt-3 from-bottom">View My Profil</a>
  </div>
</section>

<!-- Services Section -->
<section id="services">
  <div class="container">
    <h2 class="text-center mb-5 from-top">Our Services</h2>
    <div class="row g-4">
      <?php
      $result = $conn->query("SELECT * FROM services");
      if ($result && $result->num_rows > 0):
        while ($row = $result->fetch_assoc()):
      ?>
      <div class="col-md-4 from-bottom">
        <div class="card h-100 shadow-sm">
          <img src="<?php echo $row['image']; ?>" class="card-img-top" alt="<?php echo $row['title']; ?>">
          <div class="card-body">
            <h5 class="card-title"><?php echo $row['title']; ?></h5>
            <p class="card-text"><?php echo $row['description']; ?></p>
          </div>
        </div>
      </div>
      <?php endwhile; else: ?>
        <p class="text-center text-white">Belum ada data services.</p>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- Statistik Section -->
<section id="stats">
  <div class="container">
    <h2 class="text-center mb-5 from-top">Statistik</h2>
    <canvas id="statsChart" height="150"></canvas>
  </div>
</section>

<!-- Contact Section -->
<section id="contact">
  <div class="container">
    <h2 class="text-center mb-5 from-top">Contact Me</h2>
    <div class="row justify-content-center">
      <div class="col-md-6 from-bottom">
        <form method="POST" action="save_contact.php" class="p-4 rounded shadow bg-white">
          <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Email</label>
            <input type="email" name="email" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Pesan</label>
            <textarea name="message" class="form-control" rows="3" required></textarea>
          </div>
          <button type="submit" class="btn btn-primary w-100">Kirim</button>
        </form>
      </div>
    </div>
  </div>
</section>

<footer class="bg-dark text-white text-center py-3">
  &copy; 2025 Theodore Roxy Indra Putra. All Rights Reserved.
</footer>

<script src="bootstrap-5.3.8-dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
  // Fade-in on scroll
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => { if(entry.isIntersecting) entry.target.classList.add("show"); });
  }, { threshold: 0.1 });
  document.querySelectorAll(".from-left,.from-right,.from-top,.from-bottom").forEach(el=>observer.observe(el));

  // Chart JS Vertikal
  const ctx = document.getElementById('statsChart').getContext('2d');
  let chartCreated = false;
  const observerChart = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if(entry.isIntersecting && !chartCreated){
        chartCreated = true;
        <?php
        $labels = [];
        $values = [];
        $result = $conn->query("SELECT label, value FROM chart_data ORDER BY id ASC");
        while($row = $result->fetch_assoc()){
          $labels[] = $row['label'];
          $values[] = $row['value'];
        }
        ?>
        new Chart(ctx, {
          type:'bar',
          data:{
            labels: <?php echo json_encode($labels); ?>,
            datasets:[{
              label:'Jumlah (%)',
              data: <?php echo json_encode($values); ?>,
              backgroundColor: 'rgba(54,162,235,0.6)',
              borderColor: 'rgba(54,162,235,1)',
              borderWidth:1
            }]
          },
          options:{
            indexAxis: 'x',
            responsive:true,
            plugins:{ legend:{display:false} },
            scales:{ y:{ beginAtZero:true, max:100 } },
            animation:{ duration:1500, easing:'easeOutBounce' }
          }
        });
      }
    });
  }, { threshold: 0.3 });
  observerChart.observe(document.getElementById('statsChart'));
});
</script>
</body>
</html>