<?php
include 'db.php';
header('Content-Type: application/json');

$result = $conn->query("SELECT label, value FROM chart_data ORDER BY id ASC");
$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}
echo json_encode($data);
