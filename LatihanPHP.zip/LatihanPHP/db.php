<?php
$host = "localhost";
$user = "user20232034";   // sesuaikan dengan user MySQL kamu
$pass = "kmjSK7";       // kalau ada password isi di sini
$db   = "user20232034"; // nama database

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
